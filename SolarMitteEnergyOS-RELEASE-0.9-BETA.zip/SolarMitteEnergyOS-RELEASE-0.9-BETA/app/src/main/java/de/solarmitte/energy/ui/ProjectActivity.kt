
package de.solarmitte.energy.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import de.solarmitte.energy.R

class ProjectActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project)
    }
}
