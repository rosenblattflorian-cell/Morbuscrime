
package de.solarmitte.energy.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import de.solarmitte.energy.R
import android.content.Intent

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.newProjectBtn).setOnClickListener {
            startActivity(Intent(this, ProjectActivity::class.java))
        }
    }
}
